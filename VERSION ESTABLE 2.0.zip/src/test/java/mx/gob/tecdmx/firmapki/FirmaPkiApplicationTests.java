package mx.gob.tecdmx.firmapki;

import org.junit.jupiter.api.Test;
import org.springframework.boot.test.context.SpringBootTest;

@SpringBootTest
class FirmaPkiApplicationTests {

	@Test
	void contextLoads() {
	}

}
