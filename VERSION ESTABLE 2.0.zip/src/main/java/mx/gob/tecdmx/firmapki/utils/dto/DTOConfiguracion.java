package mx.gob.tecdmx.firmapki.utils.dto;

public class DTOConfiguracion {
	
	boolean config;
	String atributo;

	public boolean isConfig() {
		return config;
	}

	public void setConfig(boolean config) {
		this.config = config;
	}

	public String getAtributo() {
		return atributo;
	}

	public void setAtributo(String atributo) {
		this.atributo = atributo;
	}


}
