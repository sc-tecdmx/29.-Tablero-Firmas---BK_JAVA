package mx.gob.tecdmx.firmapki.api.escritorio;

public class PayloadCertLoginEscritorio {
	
	byte[] certificado;

	public byte[] getCertificado() {
		return certificado;
	}

	public void setCertificado(byte[] certificado) {
		this.certificado = certificado;
	}
	
	

}
