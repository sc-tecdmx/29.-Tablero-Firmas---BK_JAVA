package mx.gob.tecdmx.firmapki.api.documento;

public class PayloadEnviarDocumento {

	int idDocumento;

	public int getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(int idDocumento) {
		this.idDocumento = idDocumento;
	}

	
   
}
