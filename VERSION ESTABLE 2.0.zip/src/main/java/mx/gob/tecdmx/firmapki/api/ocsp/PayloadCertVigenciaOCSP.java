package mx.gob.tecdmx.firmapki.api.ocsp;

public class PayloadCertVigenciaOCSP {
	byte[] certificado;
	
	public byte[] getCertificado() {
		return certificado;
	}
	public void setCertificado(byte[] certificado) {
		this.certificado = certificado;
	}
	
	
}
