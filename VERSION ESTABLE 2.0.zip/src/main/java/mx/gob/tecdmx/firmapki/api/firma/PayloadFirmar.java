package mx.gob.tecdmx.firmapki.api.firma;

public class PayloadFirmar {
	int idDocumento;

	public int getIdDocumento() {
		return idDocumento;
	}

	public void setIdDocumento(int idDocumento) {
		this.idDocumento = idDocumento;
	}
	
	

}
