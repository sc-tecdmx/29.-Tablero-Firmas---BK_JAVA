package mx.gob.tecdmx.firmapki.entity.tab;

import java.io.Serializable;

public class IddocumentoIddocconfigID implements Serializable {
	
    private Integer idDocumento;
    private Integer idDocConfig;
    
	public Integer getIdDocumento() {
		return idDocumento;
	}
	public void setIdDocumento(Integer idDocumento) {
		this.idDocumento = idDocumento;
	}
	public Integer getIdDocConfig() {
		return idDocConfig;
	}
	public void setIdDocConfig(Integer idDocConfig) {
		this.idDocConfig = idDocConfig;
	}
	
    
    
    
}
